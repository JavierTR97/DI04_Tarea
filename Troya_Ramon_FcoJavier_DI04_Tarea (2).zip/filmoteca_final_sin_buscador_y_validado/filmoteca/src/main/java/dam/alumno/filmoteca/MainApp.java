package dam.alumno.filmoteca;

import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.util.List;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("/dam/alumno/filmoteca/main-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 600);
        scene.getStylesheets().add(getClass().getResource("/dam/alumno/filmoteca/estilos.css").toExternalForm());
        stage.setTitle("FILMOTECA");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    public void init() {
        System.out.println("Cargando datos desde fichero datos/peliculas.json");
        DatosFilmoteca datosFilmoteca = DatosFilmoteca.getInstance();
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            InputStream input = getClass().getResourceAsStream("/datos/peliculas.json");
            List<Pelicula> lista = objectMapper.readValue(input,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, Pelicula.class));
            datosFilmoteca.getListaPeliculas().setAll(lista);
        } catch (IOException e) {
            System.out.println("ERROR al cargar los datos. La aplicación no puede iniciarse");
            e.printStackTrace();
            System.exit(1);
        }
        System.out.println(datosFilmoteca.getListaPeliculas());
    }

    public void stop() {
        ObservableList<Pelicula> listaPeliculas = DatosFilmoteca.getInstance().getListaPeliculas();
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            File output = new File("peliculas_guardadas.json");
            objectMapper.writeValue(output, listaPeliculas);
        } catch (IOException e) {
            System.out.println("ERROR no se ha podido guardar los datos de la aplicación");
            e.printStackTrace();
        }
    }
}
package dam.alumno.filmoteca;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class FormularioPeliculaController {

    @FXML private TextField idField;
    @FXML private TextField titulo;
    @FXML private TextField year;
    @FXML private TextArea descripcion;
    @FXML private Slider rating;
    @FXML private TextField posterUrl;
    @FXML private ImageView posterImage;
    @FXML private Button guardarBtn;
    @FXML private Button cancelarBtn;

    private Pelicula pelicula;
    private Stage dialogStage;
    private boolean okClicked = false;

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public boolean isOkClicked() {
        return okClicked;
    }

    public void setPelicula(Pelicula pelicula) {
        this.pelicula = pelicula;

        if (pelicula != null) {
            idField.setText(String.valueOf(pelicula.getId()));
            titulo.setText(pelicula.getTitle());
            year.setText(String.valueOf(pelicula.getYear()));
            descripcion.setText(pelicula.getDescription());
            rating.setValue(pelicula.getRating());
            posterUrl.setText(pelicula.getPosterUrl());
            if (pelicula.getPosterUrl() != null && !pelicula.getPosterUrl().isEmpty()) {
                posterImage.setImage(new Image(pelicula.getPosterUrl(), true));
            }
        }
    }

    @FXML
    private void initialize() {
        posterUrl.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && newVal.startsWith("http")) {
                try {
                    posterImage.setImage(new Image(newVal, true));
                } catch (Exception ignored) {
                    posterImage.setImage(null);
                }
            } else {
                posterImage.setImage(null);
            }
        });

        guardarBtn.setOnAction(e -> handleGuardar());
        cancelarBtn.setOnAction(e -> dialogStage.close());
    }

    private void handleGuardar() {
        if (esValido()) {
    if (pelicula == null) pelicula = new Pelicula();
            pelicula.setTitle(titulo.getText());
            pelicula.setYear(Integer.parseInt(year.getText()));
            pelicula.setDescription(descripcion.getText());
            pelicula.setRating((int) rating.getValue());
            pelicula.setPosterUrl(posterUrl.getText().isEmpty() ? "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/480px-No_image_available.svg.png" : posterUrl.getText());

            okClicked = true;
            dialogStage.close();
        }
    }

    private boolean esValido() {
        String errorMessage = "";

        if (titulo.getText() == null || titulo.getText().trim().isEmpty()) {
            errorMessage += "Título no válido\n";
        }

        if (year.getText() == null || !year.getText().matches("\\d+")) {
            errorMessage += "Año debe ser un número\n";
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Campos inválidos");
            alert.setHeaderText("Por favor corrige los errores");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
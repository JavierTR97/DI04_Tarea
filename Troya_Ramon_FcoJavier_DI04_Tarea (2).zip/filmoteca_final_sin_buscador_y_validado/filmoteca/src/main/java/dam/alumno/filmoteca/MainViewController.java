package dam.alumno.filmoteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;

public class MainViewController {

    @FXML
    private ListView<Pelicula> listViewPeliculas;

    @FXML
    private AnchorPane detallePane;

    @FXML
    public void initialize() {
        listViewPeliculas.getItems().setAll(DatosFilmoteca.getInstance().getListaPeliculas());
    }

    @FXML
    private void onSeleccionarPelicula(MouseEvent event) {
        Pelicula seleccionada = listViewPeliculas.getSelectionModel().getSelectedItem();
        if (seleccionada != null) {
            URL fxmlUrl = getClass().getResource("/dam/alumno/filmoteca/PeliculaDetalleView.fxml");
            System.out.println("FXML URL: " + fxmlUrl);
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Pane detalle;
            try {
                detalle = loader.load();
            } catch (IOException | RuntimeException ex) {
                ex.printStackTrace();
                mostrarError("Error al cargar el detalle", ex.toString());
                return;
            }

            PeliculaDetalleController controller = loader.getController();
            controller.setPelicula(seleccionada);

            detallePane.getChildren().setAll(detalle);
            AnchorPane.setTopAnchor(detalle, 0.0);
            AnchorPane.setRightAnchor(detalle, 0.0);
            AnchorPane.setBottomAnchor(detalle, 0.0);
            AnchorPane.setLeftAnchor(detalle, 0.0);

        }
    }

    @FXML
    private void onAnadirPelicula() {
        Pelicula nueva = Dialogos.mostrarDialogoFormulario(null);
        if (nueva != null) {
            DatosFilmoteca.getInstance().getListaPeliculas().add(nueva);
            listViewPeliculas.getItems().add(nueva);
            listViewPeliculas.refresh();
            listViewPeliculas.getSelectionModel().select(nueva);
        }
    }

    @FXML
    private void onModificarPelicula() {
        Pelicula seleccionada = listViewPeliculas.getSelectionModel().getSelectedItem();
        if (seleccionada == null) {
            mostrarAviso("Debes seleccionar una película para modificar.");
            return;
        }

        Pelicula modificada = Dialogos.mostrarDialogoFormulario(seleccionada);
        if (modificada != null) {
            int index = listViewPeliculas.getSelectionModel().getSelectedIndex();
            DatosFilmoteca.getInstance().getListaPeliculas().set(index, modificada);
            listViewPeliculas.getItems().set(index, modificada);
            listViewPeliculas.getSelectionModel().select(modificada);
        }
    }

    @FXML
    private void onBorrarPelicula() {
        Pelicula seleccionada = listViewPeliculas.getSelectionModel().getSelectedItem();
        if (seleccionada == null) {
            mostrarAviso("Debes seleccionar una película para borrar.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmar borrado");
        alert.setHeaderText("¿Estás seguro de que quieres borrar la película?");
        alert.setContentText(seleccionada.getTitle());

        Optional<ButtonType> resultado = alert.showAndWait();
        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            DatosFilmoteca.getInstance().getListaPeliculas().remove(seleccionada);
            listViewPeliculas.getItems().remove(seleccionada);
            detallePane.getChildren().clear();
        }
    }

    @FXML
    private void onSalir() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Salir de la aplicación");
        alert.setHeaderText("¿Estás seguro de que quieres salir?");
        Optional<ButtonType> resultado = alert.showAndWait();

        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            DatosFilmoteca.getInstance().guardarPeliculas();
            System.exit(0);
        }
    }

    private void mostrarAviso(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}

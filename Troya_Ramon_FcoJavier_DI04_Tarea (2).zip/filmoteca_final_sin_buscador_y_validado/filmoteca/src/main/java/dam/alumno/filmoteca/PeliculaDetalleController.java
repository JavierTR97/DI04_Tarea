package dam.alumno.filmoteca;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class PeliculaDetalleController {

    @FXML private ImageView poster;
    @FXML private Label titulo;
    @FXML private Label year;
    @FXML private Label descripcion;
    @FXML private Label rating;
    @FXML private Button modificarBtn;
    @FXML private Button eliminarBtn;

    private Pelicula pelicula;

    public void setPelicula(Pelicula p) {
        if (p == null) return;
        this.pelicula = p;

        titulo.setText("Título: " + p.getTitle());
        year.setText("Año: " + p.getYear());
        descripcion.setText("Descripción: " + p.getDescription());
        rating.setText("Puntuación: " + p.getRating());

        String url = p.getPosterUrl();
        if (url != null && !url.trim().isEmpty() && url.startsWith("http")) {
            try {
                poster.setImage(new Image(url, true));
            } catch (Exception e) {
                poster.setImage(new Image("https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/480px-No_image_available.svg.png", true));
            }
        } else {
            poster.setImage(new Image("https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/480px-No_image_available.svg.png", true));
        }

        modificarBtn.setOnAction(e -> {
            Dialogos.mostrarDialogoFormulario(p);
            poster.getScene().getWindow().hide();
        });
        eliminarBtn.setOnAction(e -> {
            DatosFilmoteca.getInstance().getListaPeliculas().remove(p);
            poster.getScene().getWindow().hide();
            poster.getScene().getWindow().hide();
        });
    }
}
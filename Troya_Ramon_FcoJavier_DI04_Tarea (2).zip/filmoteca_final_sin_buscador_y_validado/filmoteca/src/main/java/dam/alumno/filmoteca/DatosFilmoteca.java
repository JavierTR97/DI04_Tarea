package dam.alumno.filmoteca;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class DatosFilmoteca {

    private static final String RUTA_JSON = "peliculas.json";
    private static DatosFilmoteca instancia;

    private final ObservableList<Pelicula> listaPeliculas;

    private DatosFilmoteca() {
        listaPeliculas = FXCollections.observableArrayList();
        cargarPeliculas();
    }

    public static DatosFilmoteca getInstance() {
        if (instancia == null) {
            instancia = new DatosFilmoteca();
        }
        return instancia;
    }

    public ObservableList<Pelicula> getListaPeliculas() {
        return listaPeliculas;
    }

    public void cargarPeliculas() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            File archivo = new File(RUTA_JSON);
            if (archivo.exists()) {
                List<Pelicula> peliculas = mapper.readValue(archivo, new TypeReference<List<Pelicula>>() {});
                listaPeliculas.setAll(peliculas);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guardarPeliculas() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(RUTA_JSON), listaPeliculas);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package dam.alumno.filmoteca;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

import java.util.Optional;

public class Dialogos {

    public static Pelicula mostrarDialogoFormulario(Pelicula pelicula) {
        Dialog<Pelicula> dialog = new Dialog<>();
        dialog.setTitle(pelicula == null ? "Añadir Película" : "Modificar Película");

        // Botones OK y Cancelar
        ButtonType okButtonType = new ButtonType("Guardar", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okButtonType, ButtonType.CANCEL);

        // Campos del formulario
        TextField tituloField = new TextField();
        TextField yearField = new TextField();
        TextArea descripcionArea = new TextArea();
        TextField ratingField = new TextField();
        TextField posterField = new TextField();

        descripcionArea.setWrapText(true);
        descripcionArea.setPrefRowCount(4);

        if (pelicula != null) {
            tituloField.setText(pelicula.getTitle());
            yearField.setText(String.valueOf(pelicula.getYear()));
            descripcionArea.setText(pelicula.getDescription());
            ratingField.setText(String.valueOf(pelicula.getRating()));
            posterField.setText(pelicula.getPosterUrl());
        }

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        grid.add(new Label("Título:"), 0, 0);
        grid.add(tituloField, 1, 0);

        grid.add(new Label("Año:"), 0, 1);
        grid.add(yearField, 1, 1);

        grid.add(new Label("Descripción:"), 0, 2);
        grid.add(descripcionArea, 1, 2);

        grid.add(new Label("Rating:"), 0, 3);
        grid.add(ratingField, 1, 3);

        grid.add(new Label("URL del póster:"), 0, 4);
        grid.add(posterField, 1, 4);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == okButtonType) {
                try {
                    String titulo = tituloField.getText() != null ? tituloField.getText().trim() : "";
                    int year = Integer.parseInt(yearField.getText() != null ? yearField.getText().trim() : "");
                    String descripcion = descripcionArea.getText() != null ? descripcionArea.getText().trim() : "";
                    double rating = Double.parseDouble(ratingField.getText() != null ? ratingField.getText().trim() : "");
                    String poster = posterField.getText() != null ? posterField.getText().trim() : "";

                    if (titulo.isEmpty() || descripcion.isEmpty() || poster.isEmpty()) {
                        mostrarAlerta("Campos obligatorios", "Rellena todos los campos obligatorios.");
                        return null;
                    }

                    return new Pelicula(titulo, descripcion, year, rating, poster);

                } catch (NumberFormatException e) {
                    mostrarAlerta("Error de formato", "Año debe ser entero y Rating debe ser decimal.");
                }
            }
            return null;
        });

        Optional<Pelicula> resultado = dialog.showAndWait();
        return resultado.orElse(null);
    }

    public static boolean mostrarConfirmacion(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    public static void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
